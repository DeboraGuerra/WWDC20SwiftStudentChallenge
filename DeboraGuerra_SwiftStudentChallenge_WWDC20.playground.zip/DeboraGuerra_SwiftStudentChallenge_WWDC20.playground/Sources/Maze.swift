import Foundation
import SpriteKit

public class Maze: SKSpriteNode {
    let mazeBlockDimension = 20
    
    func create(mazeTextFileName: String,
                wallImgName: String,
                doorImgName: String,
                closedDoorImgName: String) {
        
        self.size = CGSize(width: 480, height: 400)
        
        let mazePath = Bundle.main.path(forResource: mazeTextFileName,
                                        ofType: "txt")!
        
        do {
            let mazeString = try String(contentsOfFile: mazePath)
            let lines = mazeString.components(separatedBy: "\n") as [String]
            
            for (row, line) in lines.enumerated().reversed() {
                for (column, letter) in line.enumerated() {
                    
                    let position = CGPoint(x: (mazeBlockDimension * column) +                            (mazeBlockDimension / 2),
                                           y: (mazeBlockDimension * row) +
                                              (mazeBlockDimension / 2))
                    
                    let zPosition = CGFloat(ZPositionTypes.MazePlayerAndWallAndDoor.rawValue)
                    
                    if letter == "x" {
                        // loading wall
                        let wallNode = SKSpriteNode(imageNamed: wallImgName)
                        wallNode.position = position
                        wallNode.zPosition = zPosition
                        
                        wallNode.physicsBody = SKPhysicsBody(rectangleOf: wallNode.size)
                        wallNode.physicsBody?.categoryBitMask = ColisionTypes.Wall.rawValue
                        wallNode.physicsBody?.isDynamic = false
                        
                        self.addChild(wallNode)
                        
                    } else if letter == "d" {
                        // load door
                        let doorNode = SKSpriteNode(imageNamed: doorImgName)
                        doorNode.position = position
                        doorNode.zPosition = zPosition
                        doorNode.name = "door"
                        
                        doorNode.physicsBody = SKPhysicsBody(rectangleOf: doorNode.size)
                        doorNode.physicsBody?.categoryBitMask = ColisionTypes.Door.rawValue
                        doorNode.physicsBody?.contactTestBitMask = ColisionTypes.Player.rawValue
                        doorNode.physicsBody?.collisionBitMask = 0
                        doorNode.physicsBody?.isDynamic = false
                        
                        self.addChild(doorNode)
                        
                    } else if letter == "c" {
                        // load closed door
                        let closedDoorNode = SKSpriteNode(imageNamed: closedDoorImgName)
                        closedDoorNode.position = position
                        closedDoorNode.zPosition = zPosition
                        
                        closedDoorNode.physicsBody = SKPhysicsBody(rectangleOf: closedDoorNode.size)
                        closedDoorNode.physicsBody?.categoryBitMask = ColisionTypes.ClosedDoor.rawValue
                        closedDoorNode.physicsBody?.isDynamic = false
                        
                        self.addChild(closedDoorNode)
                    }
                }
            }
            
        } catch {
            print("error catching the string from txt file")
        }
    }    
}
