import Foundation
import SpriteKit

public class MazeScene: SKScene {
    
    let maze = Maze()
    let player = Player()
    let movementButtons = MovementButtons()
    
    public override func didMove(to view: SKView) {
        createScene()
        physicsWorld.contactDelegate = self
    }
    
    
    // MARK: -Setting the components of the scene
    
    func createScene() {
        if levelCounter == 0 {
            let tutorialImage = SKSpriteNode(imageNamed: "tutorial")
            
            
            tutorialImage.position = CGPoint(x: self.size.width * 0.5,
                                             y: self.size.height * 0.5)
            tutorialImage.zPosition = CGFloat(ZPositionTypes.Cutscene.rawValue)
            addChild(tutorialImage)
            tutorialImage.run(SKAction.fadeOut(withDuration: 8.0))

            let tutorialLabel = SKLabelNode(fontNamed: "Helvetica Neue Bold")
            tutorialLabel.text = "Click on each area to move to a different direction."
            tutorialLabel.fontSize = 20
            tutorialLabel.fontColor = .white
            tutorialLabel.numberOfLines = 0
            tutorialLabel.verticalAlignmentMode = .top
            tutorialLabel.lineBreakMode = .byWordWrapping
            tutorialLabel.preferredMaxLayoutWidth = self.size.width * 0.9
            tutorialLabel.position = CGPoint(x: self.size.width * 0.5,
                                             y: self.size.height * 0.95)
            tutorialLabel.zPosition = CGFloat(ZPositionTypes.Cutscene.rawValue)
            addChild(tutorialLabel)
            tutorialLabel.run(SKAction.fadeOut(withDuration: 8.0))

            levelCounter = 1
        }

        // setting movement buttons to the scene
        movementButtons.setButtonAreas(scene: self)

        // setting background
        setBackground()

        // creating maze
        setMaze()

        var spawnPoint = CGPoint()
        
        if levelCounter == 1 {
            spawnPoint = CGPoint(x: 40, y: 30)
        } else if levelCounter == 2{
            spawnPoint = CGPoint(x: 130, y: 40)
        } else if levelCounter == 3 {
            spawnPoint = CGPoint(x: 40, y: 230)
        }

        // adding character into the maze
        player.add(intoNode: maze,
                   spawnPoint: spawnPoint)

        let fogNode = SKSpriteNode(imageNamed: "fog_maze\(levelCounter)")
        fogNode.position = CGPoint(x: player.size.width *  (-1),
                                   y: player.size.height * 0.5 * (-1))
        player.addChild(fogNode)


    }


    func setMaze() {
        maze.position = CGPoint(x: 77.6, y: 56.8)
        maze.create(mazeTextFileName: "SketchMaze\(levelCounter)",
                    wallImgName: "block_w\(levelCounter)",
                    doorImgName: "block_d",
                    closedDoorImgName: "block_cd")
        addChild(maze)

        let borderMaze = SKSpriteNode(imageNamed: "border_maze\(levelCounter)")
        borderMaze.position = CGPoint(x: self.size.width * 0.5,
                                      y: self.size.height * 0.5)
        borderMaze.zPosition = CGFloat(ZPositionTypes.Border.rawValue)
        addChild(borderMaze)
    }


    func setBackground() {
        let background = SKSpriteNode(imageNamed: "background_maze\(levelCounter)")
        background.position = CGPoint(x: self.size.width / 2,
                                      y: self.size.height / 2)
        addChild(background)
    }


    func cleanScene() {
        self.removeAllActions()
        self.removeAllChildren()
    }



    // MARK: -Getting touches feedback

    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        let touch = touches.first
        let touchLocation = touch!.location(in: self)

        // setting direction buttons touch
        if movementButtons.upButtonArea.contains(touchLocation) {
            player.upButtonAreaPressed()
        } else if movementButtons.downButtonArea.contains(touchLocation) {
            player.downButtonAreaPressed()
        } else if movementButtons.leftButtonArea.contains(touchLocation) {
            player.leftButtonAreaPressed()
        } else if movementButtons.rightButtonArea.contains(touchLocation) {
            player.rightButtonAreaPressed()
        }
    }

}


// MARK: -Getting physics feedback

extension MazeScene: SKPhysicsContactDelegate {
    public func didBegin(_ contact: SKPhysicsContact) {
        // setting that the player passed through the maze
        if contact.bodyA.node?.name == "player" ||
           contact.bodyB.node?.name == "player" {

            var nextScene = SKScene()

            cleanScene()

            if levelCounter == 3 {
                nextScene = FinalScene(size: self.size)
            } else {
                nextScene = IceBridgeScene(size: self.size)
            }

            levelCounter += 1

            nextScene.scaleMode = self.scaleMode

            let transition = SKTransition.reveal(with: .right, duration: 1.0)

            self.scene?.view?.presentScene(nextScene,
                                           transition: transition)
        }
    }
}
