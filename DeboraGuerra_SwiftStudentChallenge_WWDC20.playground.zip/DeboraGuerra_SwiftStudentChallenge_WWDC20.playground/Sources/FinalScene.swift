import Foundation
import SpriteKit

public class FinalScene: SKScene {
    
    let endOfGameImage = SKSpriteNode(imageNamed: "final_scene")
    let replayButton = SKSpriteNode(imageNamed: "replay_button")
    
    override public func didMove(to view: SKView) {
        setAppearance()
    }
    
    
    // MARK: -Setting the components of the scene
    
    func showCutscene() {
        let cutscene = SKSpriteNode(imageNamed: "cutscene\(levelCounter - 1)")
        cutscene.position = CGPoint(x: self.size.width / 2,
                                    y: self.size.height / 2)
        cutscene.zPosition = CGFloat(ZPositionTypes.Cutscene.rawValue)
        addChild(cutscene)
        cutscene.run(SKAction.sequence([SKAction.wait(forDuration: 3.0),
                                        SKAction.fadeOut(withDuration: 2.0)]))
    }
    
    
    func setAppearance() {
        
        showCutscene()
        
        endOfGameImage.position = CGPoint(x: self.size.width * 0.5,
                                          y: self.size.height * 0.5)
        addChild(endOfGameImage)
        
        // -------
        
        replayButton.position = CGPoint(x: 268.8,
                                        y: 357.2)
        addChild(replayButton)
        
        // -------
        
        let replayLabel = SKLabelNode(fontNamed: "Helvetica Neue Bold")
        replayLabel.fontSize = 16
        replayLabel.fontColor = .black
        replayLabel.position = CGPoint(x: replayButton.size.width / 2 - 140,
                                       y: replayButton.size.height / 2 - 80)
        replayLabel.text = "Let's read and play again!"
        replayButton.addChild(replayLabel)
    }
    
    
    func cleanScene() {
        endOfGameImage.removeFromParent()
        replayButton.removeFromParent()
    }
    
    
    
    // MARK: -Getting touches feedback
    
    override public func touchesEnded(_ touches: Set<UITouch>,
                                      with event: UIEvent?) {
        
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        
        // setting button to next scene
        if self.replayButton.contains(touchLocation) {
            
            cleanScene()
            
            levelCounter = 0
            bridgeCounter = 1
            
            let nextScene = IntroScene(size: self.size)
            
            nextScene.scaleMode = self.scaleMode
            
            let transition = SKTransition.doorsCloseHorizontal(withDuration: 1.0)
            
            self.scene?.view?.presentScene(nextScene,
                                           transition: transition)
        }
    }
}
