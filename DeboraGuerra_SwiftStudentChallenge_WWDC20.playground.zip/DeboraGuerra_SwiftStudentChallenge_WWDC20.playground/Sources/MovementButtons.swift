import Foundation
import SpriteKit

public class MovementButtons {
    
    let upButtonArea = SKSpriteNode()
    let downButtonArea = SKSpriteNode()
    let leftButtonArea = SKSpriteNode()
    let rightButtonArea = SKSpriteNode()
    
    func setButtonAreas(scene: SKScene) {
        
        let upDownSize = CGSize(width: scene.size.height / 2,
                                height: scene.size.height / 2)
        let leftRightSize = CGSize(width: (scene.size.width -
                                          (scene.size.height / 2)) / 2,
                                          // (1200 - (1000 / 2)) / 2 = 350
                                   height: scene.size.height)
            
        // move UP --------------------
        upButtonArea.size = upDownSize
        upButtonArea.position = CGPoint(x: scene.size.width / 2,
                                        y: scene.size.height -
                                           (upDownSize.height / 2))
        
        // move DOWN --------------------
        downButtonArea.size = upDownSize
        downButtonArea.position = CGPoint(x: scene.size.width / 2,
                                          y: downButtonArea.size.height / 2)
        
        // move LEFT --------------------
        leftButtonArea.size = leftRightSize
        leftButtonArea.position = CGPoint(x: leftRightSize.width / 2,
                                          y: scene.size.height / 2)
        
        // move RIGHT --------------------
        rightButtonArea.size = leftRightSize
        rightButtonArea.position = CGPoint(x: scene.size.width -
                                              leftRightSize.width +
                                              (leftRightSize.width / 2),
                                              // 1200 - 350 + 175
                                          y: scene.size.height / 2)
        
        // adding button areas to the scene
        scene.addChild(upButtonArea)
        scene.addChild(downButtonArea)
        scene.addChild(leftButtonArea)
        scene.addChild(rightButtonArea)
    }
    
}
