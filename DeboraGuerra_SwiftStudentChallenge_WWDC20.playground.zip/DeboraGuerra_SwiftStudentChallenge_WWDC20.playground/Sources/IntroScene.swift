import Foundation
import SpriteKit

public class IntroScene: SKScene {
    
    let playButton = SKSpriteNode(imageNamed: "introScene_button")
    
    override public func didMove(to view: SKView) {
        setBackground()
        setLabels()
        setButton()
    }
    
    
    
    // MARK: -Setting the components of the scene
    
    func setBackground() {
        let background = SKSpriteNode(imageNamed: "introScene_background")
        background.position = CGPoint(x: self.size.width / 2,
                                      y: self.size.height / 2)
        addChild(background)
    }
    
    
    func setLabels() {
        let introTitleLabel = SKLabelNode(fontNamed: "Helvetica Neue Bold")
        let introTextLabel = SKLabelNode(fontNamed: "Helvetica Neue")
        let playButtonLabel = SKLabelNode(fontNamed: "Helvetica Neue Bold")
        
        introTitleLabel.fontSize = 48
        introTitleLabel.fontColor = .white
        introTitleLabel.verticalAlignmentMode = .top
        introTitleLabel.position = CGPoint(x: self.size.width * 0.5,
                                           y: self.size.height * 0.85)
        
        introTitleLabel.text = "Once upon a time,"
        addChild(introTitleLabel)
        
        // -------
        
        introTextLabel.fontSize = 20
        introTextLabel.fontColor = .white
        introTextLabel.numberOfLines = 0
        introTextLabel.verticalAlignmentMode = .top
        introTextLabel.lineBreakMode = .byWordWrapping
        introTextLabel.preferredMaxLayoutWidth = self.size.width * 0.7
        introTextLabel.position = CGPoint(x: self.size.width * 0.5,
                                          y: self.size.height * 0.7)
        
        introTextLabel.text = "there was a lonely creature that - all the time - trembled with fear of the dark and cold unknown.\nOne day, her mother gave her a book and from then on everything started to change.\n\nFor her, the adventure was about to begin…"
        addChild(introTextLabel)
        
        // -------
        
        playButtonLabel.fontSize = 26
        playButtonLabel.fontColor = .white
        playButtonLabel.position = CGPoint(x: 0,
                                           y: self.size.height / 55 * (-1))
        
        playButtonLabel.text = "Here we go!"
        playButton.addChild(playButtonLabel)
    }
    
    
    func setButton() {
        playButton.position = CGPoint(x: self.size.width * 0.5,
                                      y: self.size.height * 0.15)
        addChild(playButton)
    }
    
    
    func cleanScene() {
        self.removeAllActions()
        self.removeAllChildren()
    }
    
    
    
    // MARK: -Getting touches feedback
    
    override public func touchesEnded(_ touches: Set<UITouch>,
                                      with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        
        // setting button to next scene
        if playButton.contains(touchLocation) {
            
            cleanScene()
            
            let nextScene = MazeScene(size: self.size)
            nextScene.scaleMode = self.scaleMode
            
            let transition = SKTransition.doorway(withDuration: 2.0)
            self.scene?.view?.presentScene(nextScene,
                                           transition: transition)
        }
    }
}
