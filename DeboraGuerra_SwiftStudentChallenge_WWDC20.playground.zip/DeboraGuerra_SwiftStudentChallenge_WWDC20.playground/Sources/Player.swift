import Foundation
import SpriteKit

public class Player: SKSpriteNode {

    init() {
        var imageName = "player1_right"
        
        if levelCounter == 2 {
            imageName = "player2_up"
        } else if levelCounter == 3 {
            imageName = "player3_right"
        }
        
        if levelCounter == 1 && bridgeCounter == 1 {
            imageName = "player2_right"
        } else if levelCounter == 2 && bridgeCounter == 2 {
            imageName = "player2_up"
        }
        
        let texture = SKTexture(imageNamed: imageName)
        
        super.init(texture: texture,
                   color: .clear,
                   size: texture.size())
        
        self.name = "player"
        self.zPosition = CGFloat(ZPositionTypes.MazePlayerAndWallAndDoor.rawValue)
        self.physicsBody = SKPhysicsBody(circleOfRadius: self.size.width / 2)
        
        self.physicsBody?.categoryBitMask = ColisionTypes.Player.rawValue
        
        self.physicsBody?.contactTestBitMask = ColisionTypes.Door.rawValue |
                                               ColisionTypes.TouchableFloor.rawValue
        
        self.physicsBody?.collisionBitMask = ColisionTypes.ClosedDoor.rawValue |
                                             ColisionTypes.Wall.rawValue |
                                             ColisionTypes.Door.rawValue |
                                             ColisionTypes.TouchableFloor.rawValue
        self.physicsBody?.isDynamic = true
        self.physicsBody?.affectedByGravity = false
    }
    
    
    func add(intoNode: SKSpriteNode, spawnPoint: CGPoint) {
        self.position = spawnPoint
        intoNode.addChild(self)
    }
    
    
    //MARK: - Player actions
    
    func upButtonAreaPressed() {
        self.texture = SKTexture(imageNamed: "player\(levelCounter)_up")
        let moveUp = SKAction.moveBy(x: 0, y: 20, duration: 0.3)
        self.run(moveUp)
    }
    
    func downButtonAreaPressed() {
        self.texture = SKTexture(imageNamed: "player\(levelCounter)_down")
        let moveDown = SKAction.moveBy(x: 0, y: -20, duration: 0.3)
        self.run(moveDown)
    }
    
    func leftButtonAreaPressed() {
        self.texture = SKTexture(imageNamed: "player\(levelCounter)_left")
        let moveLeft = SKAction.moveBy(x: -20, y: 0, duration: 0.3)
        self.run(moveLeft)
    }
    
    func rightButtonAreaPressed() {
        self.texture = SKTexture(imageNamed: "player\(levelCounter)_right")
        let moveRight = SKAction.moveBy(x: 20, y: 0, duration: 0.3)
        self.run(moveRight)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
