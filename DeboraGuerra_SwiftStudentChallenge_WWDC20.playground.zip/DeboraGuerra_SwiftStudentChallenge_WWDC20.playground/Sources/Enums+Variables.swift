import Foundation


public var levelCounter: Int = 0
public var bridgeCounter: Int = 1


public enum ColisionTypes: UInt32 {
    case Player = 1
    case Wall = 2
    case Door = 4
    case ClosedDoor = 8
    case Floor = 16
    case TouchableFloor = 32
}


public enum ZPositionTypes: Float {
    case MazeFloor = 1
    case MazePlayerAndWallAndDoor = 2
    case Border = 4
    case Cutscene = 8
    
}
