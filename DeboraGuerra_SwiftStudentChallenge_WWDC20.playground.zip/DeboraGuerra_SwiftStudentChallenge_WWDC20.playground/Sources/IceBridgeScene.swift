import Foundation
import SpriteKit

public class IceBridgeScene: SKScene {
   
    let bridge = IceBridge()
    let player = Player()
    let movementButtons = MovementButtons()
    
    override public func didMove(to view: SKView) {
        createScene()
        physicsWorld.contactDelegate = self
    }
    
    
    // MARK: -Setting the components of the scene
    
    func showCutscene() {
        let cutscene = SKSpriteNode(imageNamed: "cutscene\(levelCounter - 1)")
        cutscene.position = CGPoint(x: self.size.width / 2,
                                    y: self.size.height / 2)
        cutscene.zPosition = CGFloat(ZPositionTypes.Cutscene.rawValue)
        addChild(cutscene)
        cutscene.run(SKAction.sequence([SKAction.wait(forDuration: 3.0),
                                        SKAction.fadeOut(withDuration: 2.0)]))
    }
    
    
    func createScene() {
        if levelCounter > 0 {
            showCutscene()
        }
        
        backgroundColor = .black
        
        movementButtons.setButtonAreas(scene: self)
        
        setBridge()
        
        var spawnPoint = CGPoint()
        if levelCounter == 2 {
            spawnPoint = CGPoint(x: 61.8, y: 226.6)
        } else if levelCounter == 3 {
            spawnPoint = CGPoint(x: 391.4, y: 61.8)
        }
        
        player.add(intoNode: bridge,
                   spawnPoint: spawnPoint)
    }
    
    
    func setBridge() {
        bridge.create(bridgeTextFileName: "SketchBridge\(bridgeCounter)",
                      iceBlockImgName: "block_ice",
                      nxtMazeImgName: "block_nxtMaze",
                      closedDoorImgName: "block_ice_cd")
        addChild(bridge)
    }
    
    
    func cleanScene() {
        self.removeAllActions()
        self.removeAllChildren()
    }
    
    
    
    // MARK: -Getting touches feedback
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        let touch = touches.first
        let touchLocation = touch!.location(in: self)

        // setting direction buttons area
        if movementButtons.upButtonArea.contains(touchLocation) {
            player.upButtonAreaPressed()
        } else if movementButtons.downButtonArea.contains(touchLocation) {
            player.downButtonAreaPressed()
        } else if movementButtons.leftButtonArea.contains(touchLocation) {
            player.leftButtonAreaPressed()
        } else if movementButtons.rightButtonArea.contains(touchLocation) {
            player.rightButtonAreaPressed()
        }
    }
}


// MARK: -Getting physics feedback

extension IceBridgeScene: SKPhysicsContactDelegate {
    
    public func didBegin(_ contact: SKPhysicsContact) {
        
        // setting that the player can go to the next maze
        if contact.bodyA.node?.name == "next" ||
           contact.bodyB.node?.name == "next" {

            cleanScene()
            bridgeCounter += 1

            let nextScene = MazeScene(size: self.size)

            nextScene.scaleMode = self.scaleMode

            let transition = SKTransition.reveal(with: .right,
                                                 duration: 1.0)

            self.scene?.view?.presentScene(nextScene,
                                           transition: transition)
        }
    }
}
