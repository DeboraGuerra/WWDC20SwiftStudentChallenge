import Foundation
import SpriteKit

public class IceBridge: SKSpriteNode {
    let iceBlockDimension = 41.2
    
    func create(bridgeTextFileName: String,
                iceBlockImgName: String,
                nxtMazeImgName: String,
                closedDoorImgName: String) {
        
        let bridgePath = Bundle.main.path(forResource: bridgeTextFileName,
                                        ofType: "txt")!
        
        do {
            let bridgeString = try String(contentsOfFile: bridgePath)
            let lines = bridgeString.components(separatedBy: "\n") as [String]
            
            for (row, line) in lines.enumerated().reversed() {
                for (column, letter) in line.enumerated() {
                    let position = CGPoint(x: (iceBlockDimension * Double(column)) +                            (iceBlockDimension / 2),
                                           y: (iceBlockDimension * Double(row)) +
                                              (iceBlockDimension / 2))
                    
                    let zPosition = CGFloat(ZPositionTypes.MazePlayerAndWallAndDoor.rawValue)
                    
                    if letter == "x" {
                        // loading ice block
                        let iceBlockNode = SKSpriteNode(imageNamed: iceBlockImgName)
                        iceBlockNode.position = position
                        iceBlockNode.zPosition = zPosition
                        
                        iceBlockNode.physicsBody = SKPhysicsBody(rectangleOf: iceBlockNode.size)
                        iceBlockNode.physicsBody?.categoryBitMask = ColisionTypes.Floor.rawValue
                        iceBlockNode.physicsBody?.isDynamic = false
                        
                        addChild(iceBlockNode)
                        
                    } else if letter == "n" {
                        // load block that allows to go to the next maze
                        let nxtMazeNode = SKSpriteNode(imageNamed: nxtMazeImgName)
                        nxtMazeNode.position = position
                        nxtMazeNode.zPosition = zPosition
                        nxtMazeNode.name = "next"
                        
                        nxtMazeNode.physicsBody = SKPhysicsBody(rectangleOf: nxtMazeNode.size)
                        nxtMazeNode.physicsBody?.categoryBitMask = ColisionTypes.TouchableFloor.rawValue
                        nxtMazeNode.physicsBody?.contactTestBitMask = ColisionTypes.Player.rawValue
                        nxtMazeNode.physicsBody?.collisionBitMask = 0
                        nxtMazeNode.physicsBody?.isDynamic = false
                        
                        addChild(nxtMazeNode)
                        
                    } else if letter == "o" {
                        // loading wall
                        let wallNode = SKSpriteNode(color: .black,
                                                    size: CGSize(width: iceBlockDimension,
                                                                 height: iceBlockDimension))
                        wallNode.position = position
                        wallNode.zPosition = zPosition
                        
                        wallNode.physicsBody = SKPhysicsBody(rectangleOf: wallNode.size)
                        wallNode.physicsBody?.categoryBitMask = ColisionTypes.Wall.rawValue
                        wallNode.physicsBody?.isDynamic = false
                        
                        addChild(wallNode)
                        
                    } else if letter == "c" {
                        // load closed door
                        let closedDoorNode = SKSpriteNode(imageNamed: closedDoorImgName)
                        closedDoorNode.position = position
                        closedDoorNode.zPosition = zPosition
                        
                        closedDoorNode.physicsBody = SKPhysicsBody(rectangleOf: closedDoorNode.size)
                        closedDoorNode.physicsBody?.categoryBitMask = ColisionTypes.ClosedDoor.rawValue
                        closedDoorNode.physicsBody?.isDynamic = false
                        
                        
                        addChild(closedDoorNode)
                    }
                }
            }
            
        } catch {
            print("error catching the string from txt file")
        }
    }
}
