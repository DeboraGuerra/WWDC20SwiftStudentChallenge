/*:
 # The Book Adventurer
 Once upon a time, there was a smiling and communicative little girl who talked to everyone and made friends wherever she went. Despite this, life where she lived was difficult, so she had to move to a place far away from everything she knew. In a completely unknown place and with no one to talk to but her parents who were always working to provide her with better living conditions, she ended up becoming an insecure and shy girl who could not express herself.
 
 One day, upon noticing her change of behavior, her mother began to take her to bookstores and read books to her. The little girl enjoyed the experience so much that whenever she could, she read some book and let her imagination fly. This little girl grew up and began to think about how incredible it was for writers to create universes capable of providing the reader with emotions and teachings that would help her to evolve in many different ways. For this reason, she began to dream of being a writer.
 
 Time passed and another change happened in her life: bullying. It was not easy to go through this phase where other people about her age gave her nicknames that hurt her, laughed at her and excluded her from their groups. Despite all the suffering which was like fuel to her insecurity, the books that her mother so affectionately presented to her were the ones that most helped her to disconnect herself, at least a little, from bad feelings. All this made her a stronger person and taught her to have something that those who tormented her did not have: empathy.
 
 The time to go to college came and, trying to make her family proud of her, she ended up taking a course that made her unhappy. This unhappiness, together with the fear of disappointing her parents made her face another difficulty: depression. The girl, now a woman, tried to hold on as long as she could, but there came a time when all those contained feelings, that pain and anguish, exploded. After a conversation that had terrified her for some time, she managed to make her parents understand that that situation hurt her a lot and that it needed to change.
 
 After that suffocation, the woman decided to keep her head up and, following in her father's footsteps, she went into the field of computing. What she did not expect was to be able to find herself again, to fall in love with something as intensely as she was in love with books. This passion led her to participate in IT-related research projects and, among them, the Apple Developer Academy, which made her realize that programming allowed her to reach that long dormant dream: to become a writer. She was now able to create universes, through apps and games, that would help people in the most diverse ways, in the same way that books helped her.
 
 She was able to spread her wings and fly so far, but so far away, that she made it this far.
 
 Pleasure to meet you, my name is Débora and this is my story.
 
 ![print("Hello World!")](hello_world.jpg)

 */

import PlaygroundSupport
import SpriteKit


let frame = CGRect(x: 0, y: 0, width: 624, height: 493.6)
let view = SKView(frame: frame)
let scene = IntroScene(size: frame.size)

view.presentScene(scene)
 
PlaygroundPage.current.liveView = view
